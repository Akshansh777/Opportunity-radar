### 📅 Daily Opportunity Digest

No scan has run yet. Once you finish setup and the first scheduled (or manually triggered) run completes, today's digest will appear here automatically.
