# 📅 Opportunity Radar

Scans your chosen YouTube channels every day at 7:00 AM IST, filters out clickbait/fluff,
and gives you a clean digest of real tech opportunities (internships, hackathons, hiring
challenges, open-source programs, certifications) — sorted by urgency.

**Fully free stack:**
- **Video analysis:** Gemini API (Google's free tier — no credit card, ~1,500 requests/day)
- **New-video detection:** YouTube's public RSS feed (no API key, no quota limit)
- **Scheduling:** GitHub Actions (free for public repos, and for private repos within the
  free monthly minutes quota)
- **Delivery:** Email + a small auto-updating website (GitHub Pages)

No server to rent, no API bills.

---

## How it works

1. `channels.txt` — you list the channels you want tracked (any format: full URL, `@handle`,
   or raw channel ID).
2. Every day at 7 AM IST, GitHub Actions runs `main.py`, which:
   - Resolves each channel entry to its real channel ID.
   - Checks that channel's RSS feed for videos published in the last 48 hours.
   - Sends each new video's **URL directly to Gemini** — Gemini watches/reads the video
     itself, no transcript scraping needed — and asks it to extract only genuine
     opportunities (skipping listicles, motivational fluff, vague "companies are hiring"
     content).
   - Merges duplicates (same opportunity mentioned by multiple channels), classifies each
     into 🚨 High / ⏳ Medium / 🟢 Low priority based on deadline urgency, and formats the
     digest.
   - Emails you the digest.
   - Publishes it to your GitHub Pages site and archives it, so you also have a bookmarkable
     "Opportunity Radar" page with history.

---

## Setup (about 10 minutes)

### 1. Create the repo
Create a new **GitHub repository** and upload all these files to it (keep the folder
structure — `main.py`, `requirements.txt`, `channels.txt`, `.github/workflows/daily-digest.yml`,
and the `docs/` folder all at the repo root).

### 2. Get a free Gemini API key
Go to **https://aistudio.google.com/apikey** → sign in with any Google account → "Create API
key". No credit card required. Copy the key.

### 3. Get an app password for sending email
If using Gmail:
- Go to your Google Account → Security → 2-Step Verification (turn on if not already).
- Go to **https://myaccount.google.com/apppasswords** → generate an app password for "Mail".
- Copy the 16-character password (this is `SMTP_PASS`, *not* your normal Gmail password).

(Any SMTP provider works — Outlook, Yahoo, etc. Just adjust `SMTP_HOST`/`SMTP_PORT` if not Gmail.)

### 4. Add GitHub secrets
In your repo: **Settings → Secrets and variables → Actions → New repository secret**. Add:

| Secret name | Value |
|---|---|
| `GEMINI_API_KEY` | the key from step 2 |
| `SMTP_USER` | your email address (the one sending) |
| `SMTP_PASS` | the app password from step 3 |
| `EMAIL_TO` | the email address you want the digest sent **to** |

Optional (only if not using Gmail):
| `SMTP_HOST` | e.g. `smtp.office365.com` |
| `SMTP_PORT` | e.g. `587` |

### 5. Add your channels
Edit `channels.txt` and paste in the channels you want tracked, one per line. Any of these
formats work:
```
https://www.youtube.com/@SomeChannel
@SomeChannel
UCxxxxxxxxxxxxxxxxxxxxxx
```
Commit the change.

### 6. Turn on GitHub Pages (for the website)
**Settings → Pages** → under "Build and deployment", set Source to **"Deploy from a branch"**,
branch `main`, folder `/docs`. Save. GitHub will give you a URL like
`https://yourusername.github.io/your-repo-name/` — that's your live Opportunity Radar page.

### 7. Test it
Go to the **Actions** tab → "Daily Opportunity Digest" → **Run workflow** (this is the manual
trigger, no need to wait until 7 AM). Watch it run — check the logs if anything fails, they're
verbose on purpose. When it finishes, check your email and refresh your Pages URL.

Once that test run succeeds, you're done — it will run automatically every day at 7:00 AM IST.

---

## Adjusting things later

- **Change the time:** edit the `cron` line in `.github/workflows/daily-digest.yml`.
  Cron is in UTC — 7:00 AM IST = 1:30 AM UTC (already set).
- **Change how far back it looks:** `LOOKBACK_HOURS` in `main.py` (default 48).
- **Swap the Gemini model:** `MODEL` in `main.py` (default `gemini-2.5-flash`; you can try
  a newer Flash model if you want, just check Google's current free-tier model list first).
- **Add/remove channels:** just edit `channels.txt` any time.

## Notes & limits

- Gemini's free tier caps YouTube video analysis at 8 hours of video/day total — plenty for
  a personal channel list, but if you track dozens of channels that post long videos daily,
  you could hit it. If that happens, the script logs the failure and falls back to
  analyzing just the title/description for that video.
- The RSS feed only returns each channel's most recent ~15 uploads, which is why
  `MAX_VIDEOS_PER_CHANNEL` is capped there — fine for a daily check, not meant for backfilling
  history.
- If a channel's `apply_link` shows "Check Channel Links", it means the video only pointed to
  a generic Linktree/Telegram — go check the video description yourself for the real link.
